package models

object Countries {
  
  val list = List(
    "France",
    "Austria",
    "Belgium",
    "Bulgaria",
    "Cyprus",
    "Czech Republic",
    "Denmark",
    "Estonia",
    "Finland",
    "French Guiana",
    "Germany",
    "Gibraltar",
    "Greece",
    "Guadeloupe",
    "Hungary",
    "Ireland",
    "Italy",
    "Latvia",
    "Lithuania",
    "Luxembourg",
    "Malta",
    "Martinique",
    "Netherlands",
    "Poland",
    "Portugal",
    "Reunion",
    "Romania",
    "Slovak (Republic)",
    "Slovenia",
    "Spain",
    "Sweden",
    "United Kingdom"
  )
  
}